import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { ScanCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient();
const dynamo = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
    const tableName = 'BathroomReviews'; // Replace with your DynamoDB table name

    const params = {
        TableName: tableName
    };

    try {
        // Fetch all reviews from DynamoDB
        const data = await dynamo.send(new ScanCommand(params));
        
        return {
            statusCode: 200,
            body: JSON.stringify({
                message: "Reviews fetched successfully!",
                reviews: data.Items // Reviews retrieved from the table
            }),
            headers: {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*', // Allow requests from any origin
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'GET, OPTIONS' // Allow GET and OPTIONS requests
            }
        };
    } catch (error) {
        console.error('Error fetching data from DynamoDB', error);
        return {
            statusCode: 500,
            body: JSON.stringify({
                message: 'Failed to fetch reviews',
                error: error.message
            }),
            headers: {
                'Access-Control-Allow-Origin': '*', // Ensure CORS headers are present in error responses
                'Access-Control-Allow-Headers': 'Content-Type',
                'Access-Control-Allow-Methods': 'GET, OPTIONS'
            }
        };
    }
};
