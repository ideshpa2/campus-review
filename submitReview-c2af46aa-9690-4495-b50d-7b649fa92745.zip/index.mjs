import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { PutCommand } from "@aws-sdk/lib-dynamodb";
import { DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient();
const dynamo = DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
    const tableName = 'BathroomReviews'; // Replace with your DynamoDB table name
    
    // Parse the incoming request body
    const data = JSON.parse(event.body);

    const params = {
        TableName: tableName,
        Item: {
            'Name': data.name,
            'Location': data.location,
            'Rating': parseInt(data.rating, 10), // Convert rating to integer
            'Comments': data.comments
        }
    };

    try {
        // Store the data in DynamoDB
        await dynamo.send(new PutCommand(params));
        
        // Return a success response with CORS headers
        return {
            statusCode: 200,
            headers: {
                "Access-Control-Allow-Origin": "*", // Allow requests from any domain
                "Access-Control-Allow-Headers": "Content-Type", // Allow specific headers
                "Access-Control-Allow-Methods": "POST, GET, OPTIONS" // Allow specific methods
            },
            body: JSON.stringify('Review submitted successfully')
        };
    } catch (error) {
        console.error('Error saving data to DynamoDB', error);
        
        // Return an error response with CORS headers
        return {
            statusCode: 500,
            headers: {
                "Access-Control-Allow-Origin": "*", // Ensure CORS headers are included even on error
                "Access-Control-Allow-Headers": "Content-Type",
                "Access-Control-Allow-Methods": "POST, GET, OPTIONS"
            },
            body: JSON.stringify('Failed to submit review')
        };
    }
};
